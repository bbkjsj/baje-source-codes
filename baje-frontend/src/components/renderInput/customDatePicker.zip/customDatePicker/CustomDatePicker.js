import React, { useState } from "react";
import { Calendar } from "react-modern-calendar-datepicker";
import Styles from "./customDatePicker.module.css";
import InputMask from "react-input-mask";
import { Button, Col, Row, Form, Modal } from "antd";
import styled from "styled-components";
import AppFormItem from "components/base/AppFormItem";
import { MaskedInput } from "antd-mask-input";

const StyledMaskInput = styled(InputMask)`
  padding: 4px 11px;
  width: 100%;

  border: 1px solid #d9d9d9;
  border-top-color: rgb(217, 217, 217);
  border-top-style: solid;
  border-top-width: 1px;
  border-right-color: rgb(217, 217, 217);
  border-right-style: solid;
  border-right-width: 1px;
  border-bottom-color: rgb(217, 217, 217);
  border-bottom-style: solid;
  border-bottom-width: 1px;
  border-left-color: rgb(217, 217, 217);
  border-left-style: solid;
  border-left-width: 1px;
  border-image-source: initial;
  border-image-slice: initial;
  border-image-width: initial;
  border-image-outset: initial;
  border-image-repeat: initial;
  border-radius: 2px;
  border-top-left-radius: 2px;
  border-top-right-radius: 2px;
  border-bottom-right-radius: 2px;
  border-bottom-left-radius: 2px;
`;

const OpenCalenderBtn = styled.p`
  padding: 8px 15px;
  cursor: pointer;
  border-top-left-radius: 4px;
  border-bottom-left-radius: 4px;
  color: #2f75b5;
  transition: all 0.5s;
  position: absolute;
  top: 0;
  left: 0;
  border: 1px solid transparent;
  &:hover {
    background-color: #eee;
  }
`;

const CustomDatePicker = (props) => {
  const [selectedDay, setSelectedDay] = useState(null);
  const [modal, setModal] = useState(false);

  const handleSetDate = (date) => {
    if (date) {
      setSelectedDay(date);
      let month =
        date.month.toString().length === 1 ? `0${date.month}` : date.month;
      let day = date.day.toString().length === 1 ? `0${date.day}` : date.day;
      let tostring = `${date.year}/${month}/${day}`;

      if (props.dynamicForm) {
        let values = props.form.getFieldsValue();

        if (values[props.dynamicFormName]) {
          if (values[props.dynamicFormName][props.name[0]]) {
            values[props.dynamicFormName][props.name[0]] = {
              ...values[props.dynamicFormName][props.name[0]],
              [props.name[1]]: `${date.year}/${month}/${day}`,
            };
          } else {
            values[props.dynamicFormName][props.name[0]] = {
              [props.name[1]]: `${date.year}/${month}/${day}`,
            };
          }
        }

        props.form.setFieldsValue({
          [props.dynamicFormName]: [...values[props.dynamicFormName]],
        });

        if (props.onChangeDynamic)
          props.onChangeDynamic(
            props.dynamicFormName,
            props.name[0],
            props.form
          );
      } else {
        props.form.setFieldsValue({ [props.name]: tostring });
      }
      props.onChange && props.onChange();
      setModal(false);
    }
  };

  const formItem = (
    <AppFormItem
      style={{ marginBottom: "0" }}
      label={props.label}

      // rules={props.rules}
      // name="customDatePicker"
    >
      <Row>
        <Col span={24} style={{ position: "relative" }} className="custom-datepicker">
          <AppFormItem
            {...props.field}
            fieldKey={props.fieldKey && props.fieldKey}
            name={props.name}
            rules={props.rules}
            validateFirst
          >
            <MaskedInput
              mask="1111/11/11"
              onChange={props.onChange ? props.onChange : undefined}
              disabled={props.disabled}
            />
          </AppFormItem>
          {!props.disabled && (
            <OpenCalenderBtn onClick={() => setModal(true)}>
              تقویم
            </OpenCalenderBtn>
          )}
        </Col>
      </Row>
    </AppFormItem>
  );

  return (
    <>
      <Modal
        width={400}
        bodyStyle={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          padding: "0",
        }}
        title="انتخاب تاریخ"
        visible={modal}
        onOk={() => setModal(false)}
        onCancel={() => setModal(false)}
        footer={false}
      >
        <Calendar
          locale="fa"
          value={selectedDay}
          onChange={(date) => {
            handleSetDate(date);
          }}
          maximumDate={props.maximumDate && props.maximumDate}
          // wrapperClassName={zIndex}
          calendarClassName={Styles.calender}
        />
      </Modal>

      {props.plain ? (
        formItem
      ) : (
        <Col xs={24} sm={24} md={24} lg={12} xl={6}>
          {formItem}
        </Col>
      )}
    </>
  );
};

export default CustomDatePicker;
